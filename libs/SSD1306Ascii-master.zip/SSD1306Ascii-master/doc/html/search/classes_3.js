var searchData=
[
  ['tickerstate',['TickerState',['../struct_ticker_state.html',1,'']]]
];
